<?php

final class Api {
    public const PX_AUTH = '';
    public const PX_TYPE = '';
    public const PROXY = self::PX_TYPE . '://' . self::PX_AUTH;

    public const KEY = [
        'tertuyul' => ['ep' => 'http://tertuyul.my.id', 'cls' => tertuyul::class],
        'solverify' => ['ep' => 'https://solverify.net', 'cls' => solverify::class],
        'xevil' => ['ep' => 'Xevil_check_bot.t.me',  'cls' => xevil::class],
        'skibidixxx' => ['ep' => 'https://waryono.my.id', 'cls' => skibidixxx::class],
        'capsolver' => ['ep' => 'https://capsolver.com', 'cls' => capsolver::class],
        'multibot' => ['ep' => 'http://multibot.in', 'cls' => multibot::class],
        'gmxch' => ['ep' => 'gamamoch', 'cls' => gmxch::class],
        'glitch' => ['ep' => 'https://buxads.com/api-token', 'cls' => glitch::class], 
    ];

    public static function use($API, $KEY): Provider {
        $a = trim($API);
        $k   = strtolower($a);
        $cfg = self::KEY[$a] ?? self::KEY[$k] ?? null;
        
        if (!$cfg) {
            foreach (self::KEY as $r) {
                if (($r['ep'] ?? null) === $a) { $cfg = $r; break; }
            }
        }
        if (!$cfg) {
            throw new Exception("invalid $API");
        }
        $cls = $cfg['cls'];
        return new $cls($KEY);
    }

    public const TKN = [

        solverify::class => [
            'cft' => [
                'k'=>'websiteKey','url'=>'websiteURL','api'=>'turnstile'
                ],
        ],

        gmxch::class => [
            'shortlink' => true,
            'cft' => [
                'k'=>'siteKey','url'=>'domain','api'=>'cloudflare', 'defaults' => ['method' => 'turnstile'], 'map' => ['cdata' => 'cData']
                ],

            'cf' => [
                'k'=>'siteKey','url'=>'domain','api'=>'popularcaptcha', 'defaults' => ['method' => 'turnstile']
                ],
            'hc' => [
                'k'=>'siteKey','url'=>'domain','api'=>'popularcaptcha', 'defaults' => ['method' => 'hcaptcha']
                ],
            /*
            'rc2' => [
                'k'=>'siteKey','url'=>'domain','api'=>'popularcaptcha', 'defaults' => ['method' => 'recaptcha2']
                ],
            'rc3' => [
                'k'=>'siteKey','url'=>'domain','api'=>'popularcaptcha', 'defaults' => ['method' => 'recaptcha3']
                ],
            */

            'pcc' => [
                'k'=>'cpobj','url'=>'domain','api'=>'coinclix', 'defaults' => ['method' => 'pc']
                ],
            'icc' => [
                'k'=>'cpobj','url'=>'domain','api'=>'coinclix', 'defaults' => ['method' => 'ic']
                ],
        ],

        tertuyul::class => [
            'shortlink' => true,
            '_proxy_format' => 'split',
            'cft' => [
                'k' => 'sitekey','url' => 'pageurl','api' => 'turnstile'
                ],
            'rc2' => [
                'k' => 'googlekey','url' => 'pageurl','api' => 'userrecaptcha'
                ],
            'rc3' => [
                'k' => 'googlekey','url' => 'pageurl','api' => 'userrecaptcha','need' => ['action'],
                'defaults' => ['version' => 'v3']
                ],
        ],

        xevil::class => [
            '_proxy_format' => 'split',
            'cft' => [
                'k' => 'sitekey','url' => 'pageurl','api' => 'turnstile'
                ],
            'hc'  => [
                'k' => 'sitekey','url' =>'pageurl','api' => 'hcaptcha'
                ],
            'rc2' => [
                'k' => 'sitekey','url' => 'pageurl','api' => 'userrecaptcha'
                ],
            'rc3' => [
                'k' => 'sitekey','url' => 'pageurl','api' => 'userrecaptcha','need' => ['action'], 
                'defaults' => ['version' => 'v3']
                ],
        ],

        multibot::class => [
            '_proxy_format' => 'uri',
            'cft' => [
                'k' => 'sitekey','url' => 'pageurl','api' => 'turnstile', 'map' => ['cdata' => 'data']
                ],
            'hc'  => [
                'k' => 'sitekey','url' =>'pageurl','api' => 'hcaptcha',
                'map' => [
                    'invisible' => 'isInvisible'
                ]
                ],
            'rc2' => [
                'k' => 'sitekey','url' => 'pageurl','api' => 'userrecaptcha',
                'defaults' => ['version' => 'v2'],
                'map' => [
                    'invisible' => 'isInvisible'
                ]
                ],
            'rc3' => [
                'k' => 'sitekey','url' => 'pageurl','api' => 'userrecaptcha','need' => ['action'], 
                'defaults' => ['version' => 'v3']
                ],
        ],

        skibidixxx::class => [
            'shortlink' => true,
            'cft' => [
                'k' => 'sitekey', 'url' => 'domain', 'api' => 'turnstile'
                ],
            /*
            */
            'hc' => [
                'k' => 'sitekey', 'url' => 'domain', 'api' => 'hcaptcha'
                ],
            'rc2' => [
                'k' => 'sitekey', 'url' => 'domain', 'api' => 'userrecaptcha',
                'defaults' => ['version' => '2']
                ],
            'rc3' => [
                'k' => 'sitekey', 'url' => 'domain', 'api' => 'userrecaptcha',
                'defaults' => ['version' => '3']
                ],
        ],

        glitch::class => [
            'shortlink' => true,
            'cft' => [
                'k' => 'siteKey', 'url' => 'domain', 'api' => 'turnstile'
                ],
            'hc' => [
                'k' => 'siteKey', 'url' => 'domain', 'api' => 'hcaptcha'
                ],
            'rc2' => [
                'k' => 'siteKey', 'url' => 'domain', 'api' => 'recaptchav2'
                ],
            'rc3' => [
                'k' => 'siteKey', 'url' => 'domain', 'api' => 'recaptchav3'
                ],
        ],

        capsolver::class => [
            'cft' => [
                'k'=>'websiteKey','url'=>'websiteURL','api'=>'turnstile'
                ],
            'rc2' => [
                'k'=>'websiteKey','url'=>'websiteURL','api'=>'recaptchav2',
                ],
            'rc3' => [
                'k'=>'websiteKey','url'=>'websiteURL','api'=>'recaptcha3', 'need'=>['action'], 
                ],
        ],
    ];
    
    public static function cfgTkn($c, $t, $siteKey, $siteUrl, array $extra = []): array {
        
        $cfg = self::TKN[$c][$t] ?? null;
        
        if (!is_array($cfg) || empty($cfg['api']) || empty($cfg['k']) || empty($cfg['url'])) {
            throw new Exception("invalid method, change providers");
        }
        foreach (($cfg['need'] ?? []) as $k) {
            if (!array_key_exists($k, $extra)) {
                throw new Exception("missing arg: $k");
            }
        }
        
        $params = array_merge([
            $cfg['k']   => $siteKey,
            $cfg['url'] => $siteUrl
        ], ($cfg['defaults'] ?? []), $extra);
        
        $providerCfg = self::TKN[$c];
        $fmt = $providerCfg['_proxy_format'] ?? null;
        if (isset($params['proxy']) && ($params['proxy'] === 'empty' || $params['proxy'] === '')) {
            unset($params['proxy'], $params['proxytype']);
        }
        
        $px = $params['proxy'] ?? ($fmt && !isset($params['proxy']) ? self::PROXY : null);
        if ($px && $fmt) {
            $u = parse_url($px);
            if ($u && !empty($u['host']) && !empty($u['port'])) {
                $scheme = strtolower($u['scheme'] ?? self::PX_TYPE ?? 'http');
                $auth = !empty($u['user']) ? "{$u['user']}:".($u['pass'] ?? '')."@{$u['host']}:{$u['port']}" : "{$u['host']}:{$u['port']}";
                if ($fmt === 'uri') {
                    unset($params['proxytype']);
                    $params['proxy'] = "{$scheme}://{$auth}";
                }
                if ($fmt === 'split') {
                    $params['proxy'] = $auth;
                    $params['proxytype'] = $scheme;
                }
            }
        }
        
        if (!empty($cfg['map'])) {
            foreach ($cfg['map'] as $from => $to) {
                if (array_key_exists($from, $params)) {
                    $params[$to] = $params[$from];
                    unset($params[$from]);
                }
            }
        }
        return [$cfg['api'], $params];
    }

    public const B64 = [

        tertuyul::class => [
            'bitcotask' => true,
            'antibot' => true,
            'ocr' => ['t' => 'universal', 'field' => 'body'],
            'least' => ['t' => 'iconfinder', 'field' => 'body'],
            'rs_upside' => ['t' => 'upside', 'field' => 'body'],
            'upside' => ['t' => 'upside', 'field' => 'body'],
            'vie_upside' => ['t' => 'upside', 'field' => 'body'],
            'fa_icon' => ['t' => 'hunter', 'field' => 'body'],
            'icon_up' => ['t' => 'iconflip', 'field' => 'body'],
            'rs_icon' => ['t' => 'rscaptcha', 'field' => 'body'],
        ],

        glitch::class => [
            'antibot' => true,
            'ocr' => ['t' => 'textcaptcha', 'field' => 'image_base64'],
            'rs_upside' => ['t' => 'rsv2', 'field' => 'image_base64'],
            'rs_icon' => ['t' => 'rsv2', 'field' => 'image_base64'],
        ],

        xevil::class => [
            'antibot' => true,
            'ocr' => ['t' => 'base64', 'field' => 'body'],
            'upside' => ['t' => 'viefaucet', 'field' => 'body'],
            'rs_upside' => ['t' => 'viefaucet', 'field' => 'body'],
            'vie_upside' => ['t' => 'viefaucet', 'field' => 'body'],
            'icon_up' => ['t' => 'iconupfinder', 'field' => 'body'],
            'rs_icon' => ['t' => 'rscaptcha', 'field' => 'body'],
        ],

        multibot::class => [
            'antibot' => true,
            'ocr' => ['t' => 'universal', 'field' => 'body'],
            'least' => ['t' => 'iconfinder', 'field' => 'body'],
            'rs_upside' => ['t' => 'upside', 'field' => 'body'],
            'upside' => ['t' => 'upside', 'field' => 'body'],
            'vie_upside' => ['t' => 'upside', 'field' => 'body'],
            'fa_icon' => ['t' => 'cls',  'field' => 'body', 'extra' => ['type' => 'Bitcotasks']],
            'icon_up' => ['t' => 'rscaptcha', 'field' => 'body'],
            'rs_icon' => ['t' => 'rscaptcha', 'field' => 'body'],
        ],

        skibidixxx::class => [
            'antibot' => true,
            'fa_icon' => ['t' => 'bitcocaptcha', 'field' => 'base64_str'],
            'fa3_icon' => ['t' => 'bitcocaptcha_v2', 'field' => 'base64_str'],
            'earnow' => ['t' => 'shortearnow', 'field' => 'base64_str'],
            'rs_upside' => ['t' => 'upsidedown_2', 'field' => 'base64_str'],
            'rs_icon' => ['t' => 'rsicon', 'field' => 'base64_str'],
            'ocr' => ['t' => 'image-to-text','field' => 'base64_str'],
            'least' => ['t' => 'least-icons', 'field' => 'base64_str'],
            'upside' => ['t' => 'upsidedown_1', 'field' => 'base64_str'],
            'vie_upside' => ['t' => 'upsidedown_3', 'field' => 'base64_str'],
        ],

        capsolver::class => [
            'ocr' => ['t' => 'ImageToTextTask', 'field' => 'body'],
        ],

        gmxch::class => [
            'bitcotask' => true,
            'antibot' => true,
            'zercaptcha' => true,
        ],

        solverify::class => [
            'ocr' => ['t' => 'ocr', 'field' => 'body'],
        ],

    ];
    
    public static function cfgB64($c, $t, $b64): array {
        $cfg = self::B64[$c][$t] ?? null;
        
        if (!$cfg && in_array($t, ['math', '4num'])) $cfg = self::B64[$c]['ocr'] ?? null;
        
        if (!is_array($cfg) || empty($cfg['t']) || empty($cfg['field'])) throw new Exception("invalid method, change providers");
        
        $extra = $cfg['extra'] ?? []; 
        if (!is_array($extra)) $extra = [];
        
        return [$cfg['t'], array_merge([$cfg['field'] => $b64], $extra)];
    }

    public const ACC = [
        
        solverify::class => [
            'interstitial' => [
                'api' => 'interstitial','url' => 'websiteURL', 'need' => ['proxy'], 
                
            ],
            'perimeterx' => [
                'api'  => 'perimeterx','url'  => 'websiteURL','need' => ['websiteKey'],
            ],
            'datadome' => [
                'api'  => 'datadome','url'  => 'websiteURL','need' => ['captchaUrl'],
            ],
        ],
        
        gmxch::class => [
            '_proxy_format' => 'uri',
            'interstitial' => [
                'api' => 'cloudflare','url' => 'domain', 'defaults' => ['method' => 'interstitial']
            ],
            'fingerprint' => [
                'api'  => 'fingerprint','url' => 'domain','need' => ['userAgent'],
            ],
            /*
            'akamai_a' => [
                'api'  => 'akamai','url' => 'domain','defaults' => ['method' => 'abck']
            ],
            'akamai_s' => [
                'api'  => 'akamai','url' => 'domain','defaults' => ['method' => 'sbsd']
            ],
            'akamai_c' => [
                'api'  => 'akamai','url' => 'domain','defaults' => ['method' => 'censorship']
            ],
            */
        ],
        
        tertuyul::class => [
            '_proxy_format' => 'split',
            'interstitial' => [
                'api' => 'cloudflare','url' => 'pageurl', 'need' => ['proxy'], 
            ],
        ],
        
        glitch::class => [
            '_proxy_format' => 'object',
            'interstitial' => [
                'api' => 'iuam','url' => 'domain', 'need' => ['proxy'], 
            ],
        ],
        
        capsolver::class => [
            'interstitial' => [
                'api' => 'AntiCloudflareTask','url' => 'domain', 'need' => ['proxy'], 
            ],
            'datadome' => [
                'api'  => 'DatadomeSliderTask','url'  => 'websiteURL','need' => ['captchaUrl'],
            ],
        ],

        xevil::class => [
            '_proxy_format' => 'split',
            'interstitial' => [
                'api' => 'turnstile','url' => 'pageurl',
                'defaults' => ['sitekey' => 'jschallenge']
            ],
        ],
        
        multibot::class => [
            '_proxy_format' => 'split',
            'interstitial' => [
                'api' => 'turnstile','url' => 'pageurl',
                'defaults' => ['cf_clearance' => 1],
               # 'need' => ['body'] 
            ],
        ],
        
    ];
    
    public static function cfgAcc($c, $t, $siteUrl, array $extra = []): array {
        
        $cfg = self::ACC[$c][$t] ?? null;
        if (!$cfg) throw new Exception("invalid method, change providers");

        $params = array_merge([$cfg['url'] => $siteUrl], ($cfg['defaults'] ?? []), $extra);

        $fmt = self::ACC[$c]['_proxy_format'] ?? null;

        if (isset($params['proxy'])) {
            if ($params['proxy'] === 'empty' || $params['proxy'] === '') {
                unset($params['proxy'], $params['proxytype']);
            } elseif ($fmt) {
                $px = $params['proxy'];
                $u = parse_url($px);
                
                if ($u && !empty($u['host'])) {
                    $host = $u['host'];
                    $port = $u['port'] ?? 80;
                    $user = $u['user'] ?? '';
                    $pass = $u['pass'] ?? '';
                    $scheme = strtolower($u['scheme'] ?? self::PX_TYPE ?? 'http');

                    if ($fmt === 'uri') {
                        unset($params['proxytype']);
                        $auth = $user ? "{$user}:{$pass}@" : "";
                        $params['proxy'] = "{$scheme}://{$auth}{$host}:{$port}";
                    } elseif ($fmt === 'split') {
                        if (strpos(strtolower($c), 'xevil') !== false) {
                            $params['proxytype'] = $scheme;
                            $params['proxy'] = $user ? "{$host}:{$port}:{$user}:{$pass}" : "{$host}:{$port}";
                        } else {
                            unset($params['proxytype']); 
                            $auth = $user ? "{$user}:{$pass}@" : "";
                            $params['proxy'] = "{$auth}{$host}:{$port}";
                        }
                    } elseif ($fmt === 'object') {
                        $params['proxy'] = [
                            'hostname' => $host,
                            'port' => (int)$port,
                            'scheme'   => $scheme,
                            'username' => $user,
                            'password' => $pass
                        ];
                        unset($params['proxytype']);
                    }
                }
            }
        }

        if (!empty($cfg['map'])) {
            foreach ($cfg['map'] as $from => $to) {
                if (array_key_exists($from, $params)) {
                    $params[$to] = $params[$from];
                    unset($params[$from]);
                }
            }
        }
        
        #print_r($params);
        return [$cfg['api'], $params];
        
    }
    
    public const ERR = [

        'fail' => [ 
            'ERROR_CAPTCHA_UNSOLVABLE',
            "ERROR_CAPTCHA_SOLVE_FAILED",
            'ERROR_TASK_FAILED',
            'ERROR_CAPTCHA_TIMEOUT',
            'ERROR_TIMEOUT',
            'TIMEOUT after',
            'ERROR_TASK_TIMEOUT',
            'WRONG_RESULT',
            'TOTALLY_FAILED',
            'ERROR_NO_NODES_AVAILABLE',
            'ERROR_NO_SLOT_CONNECTION',
            'ERROR_NO_SLOT_AVAILABLE',
            'ERROR_INVALID_RESPONSE1',
            'ERROR_SOLVER_RESPONSE',
            'TASK_NOT_FOUND',
            'Job not found',
            'ERR_EMPTY_RESPONSE',
            'failed to respond',
            'INVALID_PARAMETERS',
            'SERVICE_BUSY',
            ],

        'ret' => [ 
            'ERROR_UNKNOWN_STATUS',
            'ERROR_REQUEST_COOLDOWN',
            'CAPTCHA_NOT_READY',
            'CAPCHA_NOT_READY',
            'ERROR_RATE_LIMIT',
            'ERROR_TOO_MANY_REQUESTS',
            'ERROR_INTERNAL_SERVER',
            'processing',
            'pending',
        ],

        'con' => [
            'ERROR_INTERNAL',
            'ERROR_BANNED',
            'ERROR_TASK_CREATION_FAILED',
            "ERROR_SOLVER_RESPONSE",
            'INTENAL_SERVER_ERROR',
            'INTERNAL_SERVER_ERROR',
            'ERROR_PROXY_CONNECTION_FAILED',
            'ERROR_CAPTCHA_SERVER_OFFLINE',
            'ERROR_SERVICE_UNAVALIABLE',
            'ERROR_SERVICE_UNAVAILABLE',
            'ERROR_PROXY_BANNED',
            'INTERNAL_SERVER_ERROR',
            'INTERNAL_SOLVER_ERROR',
            'External solver request failed',
            'returned HTTP 502',
        ],

        'err' => [
            'ERROR_IP_BANNED',
            'ERROR_TASK_TYPE_NOT_FOUND',
            'ERROR_PENDING_LIMIT_EXCEEDED',
            'ERROR_THREAD_LIMIT_EXCEEDED',
            'ERROR_TASK_NOT_FOUND',
            'WRONG_CAPTCHA_ID',
            'ERROR_WRONG_PAGEURL',
            'ERROR_SITEKEY_IS_INCORRECT',
            'SITEKEY_IS_INCORRECT',
            'ERROR_SITEKEY',
            'ERROR_INVALID_IMAGE',
            'ERROR_WRONG_DATA',
            'ERROR_INVALID_METHOD',
            'ERROR_METHOD_DOES_NOT_EXIST',
            'WRONG_METHOD',
            'ERROR_BAD_DATA',
            'ERROR_WRONG_ID_FORMAT',
            'ERROR_WRONG_CAPTCHA_ID',
            'ERROR_EMPTY_ACTION',
            'ERROR_INVALID_TASK_DATA',
            'ERROR_BAD_REQUEST',
            'ERROR_TASKID_INVALID',
            'ERROR_TASK_NOT_SUPPORTED',
            'ERROR_UNKNOWN_QUESTION',
            'ERROR_PARSE_IMAGE_FAIL',
            'WRONG_REQUESTS_LINK',
            'WRONG_LOAD_PAGEURL',
            'WRONG_COUNT_IMG',
            'TURNSTILE_NOT_FOUND',
            'HCAPTCHA_NOT_FOUND',
            'Missing domain',
            'Missing siteKey',
            'invalid mode',
            'Missing mode or action',
            'MISSING_FIELDS',
            'INVALID_TYPE',
            'INVALID_METHOD',
            'INVALID_PROXY',
            'INVALID_URL',
        ],

        'key' => [
            'ERROR_BILLING_EXPIRED',
            'ERROR_USER_NOT_FOUND',
            'ERROR_INVALID_KEY',
            'ERROR_KEY_EXPIRED',
            'ERROR_INSUFFICIENT_BALANCE',
            'ERROR_WRONG_USER_KEY',
            'ERROR_KEY_DOES_NOT_EXIST',
            'ERROR_ZERO_BALANCE',
            'ERROR_KEY_TEMP_BLOCKED',
            'ERROR_SETTLEMENT_FAILED',
            'ERROR_KEY_DENIED_ACCESS',
            'Insufficient token balance',
            'Invalid API key',
            'missing Key',
            'UNAUTHORIZED',
            'INVALID_KEY',
        ],

    ];

    public static function errType($msgOrCode) {
        $msg = trim($msgOrCode);
        if (empty($msg) || $msg === 'unknown') return 'ret';
        foreach (self::ERR as $type => $codes) {
            foreach ($codes as $c) {
                if (stripos($msg, $c) !== false) return $type;
            }
        }
        return false;
    }
    
} 

abstract class Provider {

    protected $apiKey;
    #protected $baseUrl;

    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
    }

    final public function run($method, array $params, bool $strict = false) {
        return $this->call($method, $params, $strict);
    }

    final protected function call($method, array $params, bool $strict = false) {

        for ($i = 0; $i < 3; $i++) {
            try {
                return styler(static::class . "=>$method", function() use ($method, $params) {
                    $id = $this->get_api($method, $params);
                    return ['done' => $this->res_api($id)];
                });

            } catch (Throwable $e) {

                $code = $e->getMessage();
                $type = Api::errType($code);

                Logger::X('info', "\rApi [ ".static::class.' ] ', false, true);
                Logger::X('err', "\r{$e->getMessage()}", true, true);

                if ($strict) return ['fail' => 1];

                if (in_array($type, ['ret','con','fail'], true)) {
                    _sle(3);
                    continue;
                }

                if (static::class === 'gmxch') return ['fail' => 777];

                return ['fail' => 77];
            }
        }

        if (static::class === 'gmxch') return ['fail' => 777];

        return ['fail' => 1];
    }

    public function token($siteKey, $siteUrl, $type, array $extraParams = []) {

        try {
            [$method, $params] = Api::cfgTkn(
                static::class,
                $type,
                $siteKey,
                $siteUrl,
                $extraParams
            );

        } catch (Throwable $e) {
            Logger::X('warn', "\r{$e->getMessage()}", true, true);
            return ['fail' => 71];
        }

        return $this->run($method, $params);
    }

    public function base64($img, $type = 'ocr') {

        $raw = is_file($img) ? _get($img) : $img;
        $isBase64 = (!is_file($img) && preg_match('%^[a-zA-Z0-9/+]*={0,2}$%', trim($raw)));

        $b64 = $isBase64 ? trim($raw) : base64_encode($raw);

        try {
            [$method, $params] = Api::cfgB64(
                static::class,
                $type,
                $b64
            );

        } catch (Throwable $e) {
            Logger::X('warn', "\r{$e->getMessage()}", true, true);
            return ['fail' => 71];
        }
        return $this->run($method, $params);
    }

    public function access($siteUrl, $type, array $extraParams = []) {

        try {
            [$method, $params] = Api::cfgAcc(
                static::class,
                $type,
                $siteUrl,
                $extraParams
            );

            $cfg = Api::ACC[static::class][$type];

            foreach (($cfg['need'] ?? []) as $k) {
                if (!isset($params[$k])) {
                    Logger::X('warn', "\rmissing required arg: $k for $type");
                    return ['fail' => 73];
                }
            }

            return array_merge(
                ['class' => static::class],
                $this->run($method, $params)
            );

        } catch (Exception $e) {
            Logger::X('warn', "\r{$e->getMessage()}", true, true);
            return ['fail' => 71];
        }
    }

    public function atb(array $data) {

        $pa  = [];
        $map = [];
        $i   = 0;
        foreach ($data['rels'] as $rel => $b64) {
            $pa[(string)$rel] = $b64;
            $map[(string)$rel] = $rel;
            $map[(string)$i]   = $rel;
            $i++;
        }

        $pa['main'] = $data['main'];
        $res = $this->run('antibot', $pa, true);

        if (isset($res['fail'])) return $res;
        $in = explode(',', $res['done']);

        $links = [];
        foreach ($in as $val) {
            $val = trim($val);
            if (isset($map[$val])) $links[] = $map[$val];
        }
        if (empty($links)) return ['fail' => 1];

        return [
            'done' => " " . implode(' ', $links)
        ];
    }

    abstract protected function get_api($method, array $params);

    abstract protected function res_api($jobId);
}









abstract class Providers {
    # legacy
    protected $apiKey;
    #protected $baseUrl;

    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
    }

    final public function run($method, array $params, bool $strict = false) {
        return $this->call($method, $params, $strict);
    }

    final protected function call($method, array $params, bool $strict = false) {
        for ($i = 0; $i < 3; $i++) {
            try {
                return styler(static::class . "=>$method", function() use ($method, $params) {
                    $id = $this->get_api($method, $params);
                    return $this->res_api($id);
                });
            } catch (Throwable $e) {
                $code = $e->getMessage();
                $type = Api::errType($code);
                Logger::X('info', 'Api [ '.static::class.' ] ', false, true);
                Logger::X('err', $code);
                if ($strict) return false;
                
                if (in_array($type, ['ret','con','fail'], true)) {
                    _sle(3);
                    continue;
                }
                
                if (static::class === 'gmxch') return 777;
                
                return 77;
            }
        }
        
        if (static::class === 'gmxch') return 777;
        return false;
    }
    
    public function token($siteKey, $siteUrl, $type, array $extraParams = []) {
        try {
            [$method, $params] = Api::cfgTkn(static::class, $type, $siteKey, $siteUrl, $extraParams);
        } catch (Throwable $e) {
            Logger::X('warn', $e->getMessage());
            return 71;
        }
        return $this->run($method, $params);
    }

    public function base64($img, $type = 'ocr') {
        $raw = is_file($img) ? _get($img) : $img;
        $isBase64 = (!is_file($img) && preg_match('%^[a-zA-Z0-9/+]*={0,2}$%', trim($raw)));
        $b64 = $isBase64 ? trim($raw) : base64_encode($raw);
        try {
            [$m, $params] = Api::cfgB64(static::class, $type, $b64);
        } catch (Throwable $e) {
            Logger::X('warn', $e->getMessage());
            return 71; 
        }
        $res = $this->run($m, $params);
        if (!$res) return 77;
        
        return $res;
    }

    public function access($siteUrl, $type, array $extraParams = []) {
        try {
            [$method, $params] = Api::cfgAcc(static::class, $type, $siteUrl, $extraParams);
            
            $cfg = Api::ACC[static::class][$type];
            foreach (($cfg['need'] ?? []) as $k) {
                if (!isset($params[$k])) {
                    Logger::X('warn', "missing required arg: $k for $type");
                    return 73;
                }
            }
            #print_r($params); die;
            $solved = $this->run($method, $params);
            return [static::class,$solved];

        } catch (Exception $e) {
            Logger::X('warn', $e->getMessage(), true, true);
            return 71;
        }
    }
    
    public function atb(array $data) {
        $pa = []; 
        $map = []; 
        $i = 0;
        
        foreach ($data['rels'] as $rel => $b64) {
            #_put($rel.'.png', base64_decode($b64));
            $pa[(string)$rel] = $b64;
            $map[(string)$rel] = $rel;
            $map[(string)$i] = $rel; 
            $i++;
        }
        
        $pa['main'] = $data['main'];
        #print_r($pa); 
        $res = $this->run('antibot', $pa, true);
        #Logger::X('', $res);
        if ($res === 77) return 77;
        if ($res === 777) return 777;
        if ($res === null) return null;
        
        $in = explode(',', $res);
        $links = [];
        foreach ($in as $val) {
            $val = trim($val);
            if (isset($map[$val])) {
                $links[] = $map[$val];
            }
        }

        return !empty($links) ? " " . implode(' ', $links) : false;

    }

    abstract protected function get_api($method, array $params);
    
    abstract protected function res_api($jobId);
}